<?php
session_start();

if (isset($_GET['id']) && ! empty($_GET['id'])) {

    if (! isset($_SESSION['cart'])) {
        $cart = array();
        $_SESSION['cart'] = $cart;
    }
    
    $cart = $_SESSION['cart'];
    
    // remove that array element
    $indexToDelete = -1;
    for ($i=0; $i < count($cart); $i++) {
        if ($cart[$i][0] == $_GET['id']) $indexToDelete = $i;
    }
    if ($indexToDelete > -1) {
        unset($cart[$indexToDelete]);
        array_values($cart);
    }
    
    $_SESSION['cart'] = $cart;
}
else {
    $favorites = array();
    $_SESSION['cart'] = $cart;    
}

header("Location: viewCart.php");

?>