<?php
  $nav_selected = "SETUP";
  $left_buttons = "NO";
  $left_selected = "";

  include("./nav.php");
  
 ?>

 <div class="right-content">
    <div class="container">

      <h3 style = "color: #01B0F1;">Setup (TO BE DONE LATER)</h3>

    </div>
</div>

<?php include("./footer.php"); ?>
