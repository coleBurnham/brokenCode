<?php

DEFINE('DB_SERVER', 'localhost');
DEFINE('DB_NAME', 'bom');
DEFINE('DB_USER', 'root');
DEFINE('DB_PASS', '');

?>
